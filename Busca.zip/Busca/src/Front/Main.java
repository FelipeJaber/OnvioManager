/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Front;

import java.util.Scanner;
import Script.Busca;
import java.io.IOException;

/**
 *
 * @author aluno
 */
public class Main {
    
    public static void main(String[] args){
        
        try {
            
        
        Scanner entrada = new Scanner(System.in);
        String URL = "";
        Busca busca = new Busca();
        int i = 0;
        
        
        
        URL = "C://Users//aluno//Desktop//Dictionaries-master//Portuguese (Brazilian).dic";
        
        String[] VetorNaoOrdenado = busca.AbrirArquivo(URL);
        
        String[] VetorOrdenado = busca.SelectionSort(VetorNaoOrdenado);
        
        for (int j = 0; j < VetorOrdenado.length; j++) {
            System.out.println(VetorOrdenado[j]);
        }
        
        
        
        } catch (Exception e) {
            System.out.println(e);
        }
        
        
        
    }
    
    
    
}
