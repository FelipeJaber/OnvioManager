/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Script;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

/**
 *
 * @author aluno
 */
public class Busca {
    
    public String[] SelectionSort(String[] Entrada){
        int n = Entrada.length;
        
        
        for (int i = 0; i < n-1; i++) {
            int min = i;
            
            for (int j = i+1; j < n; j++) {
                if(Entrada[j].length()< Entrada[min].length()){
                    min = j;
                }
            }
            
            String temp = Entrada[min];
            Entrada[min] = Entrada[i];
            Entrada[i] = temp;
        }
        
        return Entrada;
    }
    
    //"C:\Users\aluno\Desktop\Dictionaries-master\Portuguese (Brazilian).dic"
    
    public String[] AbrirArquivo(String URL) throws FileNotFoundException, IOException{
        
        String linha; 
        int tamanholinha;
        ArrayList<String> lista = new ArrayList<>();
        
        
        FileReader fr = new FileReader(URL);
        BufferedReader br = new BufferedReader(fr);

        while((linha=br.readLine()) != null){
            
            tamanholinha = linha.length();
            
            for (int i = 0; i < linha.length(); i++) {
                
                if((linha.charAt(i)+"").equals("/")){
                    linha = linha.substring(0, i);
                }
                
            }
            
            lista.add(linha);
        }
        
        int Tamanho = lista.size();
        String[] Saida = new String[Tamanho-1];
        
        for (int i = 0; i < Tamanho-1; i++) {
            Saida[i] = lista.get(i+1);
        }
        
        return Saida;
        
    }
    
    
    
    
    
    
    
}
